import { ImprovedHeroSection } from "@/components/improved-hero-section";

export default function Home() {
  return (
    <>
      <ImprovedHeroSection />
    </>
  );
}
